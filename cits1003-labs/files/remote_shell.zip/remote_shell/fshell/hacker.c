#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <strings.h>
#include <string.h>

void exit_with_error(const char* msg) {
	if (msg == NULL)  
		perror("The following error occurred");
	else 
		perror(msg);

	exit(EXIT_FAILURE);
}

int main() {
	int socket_id;				// socket descriptor
	struct sockaddr_in cli_sockaddr;	// socket address for client
	short port_num = 8001;			// port # for the server application
	const char* server_ip = "10.0.2.15";

	char snd_buffer[4096], rcv_buffer[4096];
	fd_set read_socket_ids;
	
	/*
	 * 1. create a socket, which will be used to wait for an incoming connection from a client
	 */
	printf("creating a socket.\n");
	if ((socket_id = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
		exit_with_error(NULL);


	/*
	 * 2. connect to the server
	 */
	printf("connecting to the server.\n");
	cli_sockaddr.sin_family = AF_INET;
	cli_sockaddr.sin_port = htons(port_num);
	cli_sockaddr.sin_addr.s_addr = inet_addr(server_ip);
	if (connect(socket_id, (struct sockaddr *) &cli_sockaddr, sizeof(cli_sockaddr)) == -1)
		exit_with_error(NULL);
	printf("now you are connected.\n");
	

	/*
	 * 3-1. select & read from stdin and write on socket_id
	 * 3-2. select & read from socket_id and write on stdout
	 */
	printf("try executing any linux commands.\n");
	while(1) {
		FD_ZERO(&read_socket_ids);
		FD_SET( fileno(stdin), &read_socket_ids);
		FD_SET( socket_id, &read_socket_ids);
		select( socket_id+1, &read_socket_ids, 0, 0, 0);

		if (FD_ISSET( fileno(stdin), &read_socket_ids)) {
			bzero(snd_buffer, sizeof(snd_buffer));
			read( fileno(stdin), snd_buffer, sizeof(snd_buffer));
			write( socket_id, snd_buffer, sizeof(snd_buffer));
		}	

		if (FD_ISSET( socket_id, &read_socket_ids)) {
			bzero(rcv_buffer, sizeof(rcv_buffer));
			if (read(socket_id, rcv_buffer, sizeof(rcv_buffer)) <=0)
				exit_with_error(NULL);
			write( fileno(stdout), rcv_buffer, sizeof(rcv_buffer));
		}
	}	
	
	return 0;	
}
