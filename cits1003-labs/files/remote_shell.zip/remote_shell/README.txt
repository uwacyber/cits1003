1. Open two terminals 
2. Compile using the makefile
3. Run the server code first
4. Run the client code next