#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <strings.h>
#include <string.h>

void exit_with_error(const char* msg) {
	if (msg == NULL)  
		perror("The following error occurred");
	else 
		perror(msg);

	exit(EXIT_FAILURE);
}

int main() {
	int socket_id;				// socket descriptor for waiting for incoming connections 
	int cli_socket_id;			// socket descriptor for an accepted connection
	struct sockaddr_in srv_sockaddr;	// socket address for server
	struct sockaddr_in cli_sockaddr;	// socket address for client
	unsigned int cli_sockaddr_size = sizeof(cli_sockaddr);
	short port_num = 8001;			// port # for the server application
	int optval;

	/*
	 * 1. create a socket, which will be used to wait for an incoming connection from a client
	 */
	printf("creating a socket.\n");
	if ((socket_id = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
		exit_with_error(NULL);

	if (setsockopt(socket_id, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) == -1) exit_with_error(NULL);

	/*
	 * 2. bind the socket to (address, port #)
	 *	(i.e., specify port # and address to use for the socket)
	 *	if the socket is a CLIENT socket, the address needs to be the SERVER address.
	 *	if the socket is a SERVER socket, the address could be ANY.
	 */
	printf("binding the socket.\n");
	srv_sockaddr.sin_family = AF_INET;
	srv_sockaddr.sin_port = htons(port_num);
	srv_sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(socket_id, (struct sockaddr *) &srv_sockaddr,	sizeof (srv_sockaddr)) == -1)
		exit_with_error(NULL);


	/*
	 * 3. start listening on the socket
	 *
	 *    parameter 1 is the max length of the queue of pending connections
	 *    for simplicity, we will accept a single connection
	 */
	printf("listening on the socket.\n");
	if (listen(socket_id, 1) == -1) 
		exit_with_error(NULL);		

	/*
	 * 4. accept an incoming connection if any
	 */
	if ((cli_socket_id = accept(socket_id, (void *)&cli_sockaddr, &cli_sockaddr_size)) == -1)
		exit_with_error(NULL);
	printf("accepting connection from %s.\n", inet_ntoa(cli_sockaddr.sin_addr));	
	printf("listening socket id: %d\n", socket_id);
	printf("new socket id: %d\n", cli_socket_id);


	char snd_buffer[4096], rcv_buffer[4096];
	fd_set read_socket_ids;

	/*
	 * 5-1. select & read from stdin and write on socket_id
	 * 5-2. select & read from socket_id and write on stdout
	 */
	printf("try executing any linux commands.\n");
	while(1) {
		FD_ZERO(&read_socket_ids);
		FD_SET( fileno(stdin), &read_socket_ids);
		FD_SET( cli_socket_id, &read_socket_ids);
		select( cli_socket_id+1, &read_socket_ids, 0, 0, 0);

		if (FD_ISSET( fileno(stdin), &read_socket_ids)) {
			bzero(snd_buffer, sizeof(snd_buffer));
			read( fileno(stdin), snd_buffer, sizeof(snd_buffer));

			if (strcmp(snd_buffer,"chdir\n")==0)
				strcpy(snd_buffer,"pwd\n");

			write( cli_socket_id, snd_buffer, sizeof(snd_buffer));
		}	

		if (FD_ISSET( cli_socket_id, &read_socket_ids)) {
			bzero(rcv_buffer, sizeof(rcv_buffer));
			if (read(cli_socket_id, rcv_buffer, sizeof(rcv_buffer)) <=0)
				exit_with_error(NULL);
			write( fileno(stdout), rcv_buffer, sizeof(rcv_buffer));
		}
	}

	return 0;	
}









