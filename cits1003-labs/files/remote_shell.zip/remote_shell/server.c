#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <strings.h>
#include <string.h>

void exit_with_error(const char* msg) {
	if (msg == NULL) perror("The following error occurred");
	else perror(msg);

	exit(EXIT_FAILURE);
}

int main() {
	while (1){		
		int socket_id;				// socket ID for listening
		int cli_socket_id;			// socket ID for new, accepted connection
		struct sockaddr_in srv_sockaddr;	// used for bind()
		struct sockaddr_in cli_sockaddr;	// used for accept()
		unsigned int cli_sockaddr_size = sizeof(cli_sockaddr);  // used for accept()
		short port_num = 8001;			// port #
		int optval;                 // used for setsockopt()

		// used for read()
		char rcv_buffer[1000];
		int nbytes;
		fd_set read_socket_ids;

		/*
		 * 1. create a socket for waiting for an incoming connection from a client
		 */
		printf("creating a socket.\n");
		if ((socket_id = socket(AF_INET, SOCK_STREAM, 0)) == -1)
			exit_with_error(NULL);

		/*
		 * 1.5 Configure additional options for socket.
		 *      SO_REUSEADDR allows binding to the same address multiple times
		 */
		if (setsockopt(socket_id, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval)) == -1) exit_with_error(NULL);

		/*
		 * 2. bind to particular (address, port #) pair
		 *	  INADDR_ANY means 'any address' - for binding only port # is of importance
		 *      and address is not of concern.
		 */
		printf("binding the socket.\n");
		srv_sockaddr.sin_family = AF_INET;
		srv_sockaddr.sin_port = htons(port_num);
		srv_sockaddr.sin_addr.s_addr = htonl(INADDR_ANY);
		if (bind(socket_id, (struct sockaddr *) &srv_sockaddr,	sizeof (srv_sockaddr)) == -1)
			exit_with_error(NULL);

		/*
		 * 3. start listening for TCP SYN
		 *    2nd argument '1' is max # of pending connections,
		 *    meaning we'll accept a single connection
		 */
		printf("listening on the socket.\n");
		if (listen(socket_id, 1) == -1)
			exit_with_error(NULL);

		/*
		 * 4. upon a connection attemp with a TCP SYN,
		 *    accept it by sending back a TCP SYN/ACK
		 *    and a new socket cli_sock_id is created,
		 *    which will be used for communication in this new connection
		 *    previous socket socket_id will continue to be used for listening & accepting
		 */
		if ((cli_socket_id = accept(socket_id, (void *)&cli_sockaddr, &cli_sockaddr_size)) == -1) exit_with_error(NULL);
		printf("accepting connection from %s.\n", inet_ntoa(cli_sockaddr.sin_addr));
		printf("listening socket id: %d\n", socket_id);
		printf("new socket id: %d\n", cli_socket_id);

		/*
		 * 5. Display any received data
		 */
		struct sockaddr_in tmpaddr = {0};
		while(1) {
			// initialize read_socket_ids to 0
			// add cli_socket_id to read_socket_ids
			FD_ZERO(&read_socket_ids);
			FD_SET(cli_socket_id, &read_socket_ids);

			// if any data arrived at cli_socket_id
			// set 1 to the corresponding bit in read_socket_ids
			select(cli_socket_id+1, &read_socket_ids, 0, 0, 0);

			// if bit corresponding to cli_socket_id is set to 1 in read_socket_ids,
			// (i.e., if any data arrived at cli_socket_id)
			if (FD_ISSET(cli_socket_id, &read_socket_ids)) {
				// initialized rcv_buffer to 0
				// read data from cli_socket_id, fill data in rcv_buffer, and display data
				bzero(rcv_buffer, sizeof(rcv_buffer));
				nbytes = read(cli_socket_id, rcv_buffer, sizeof(rcv_buffer));
				if (strcmp(rcv_buffer, "q") == 0) {
					shutdown(cli_socket_id,SHUT_RDWR);
					close(cli_socket_id);
					shutdown(socket_id,SHUT_RDWR);
					close(socket_id);
					bind(socket_id, (struct sockaddr *) &tmpaddr,sizeof (tmpaddr));
					sleep(2);	
					exit(0);
				}
				if (nbytes > 0) printf("%d bytes: %s\n", nbytes, rcv_buffer);
					
				shutdown(cli_socket_id,SHUT_RDWR);
				close(cli_socket_id);
				shutdown(socket_id,SHUT_RDWR);
				close(socket_id);
				bind(socket_id, (struct sockaddr *) &tmpaddr,sizeof (tmpaddr));
				sleep(2);	
				break;
			}
		}
	
	}
	return 0;
}
