#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <fcntl.h>	
#include <unistd.h>
#include <errno.h>
#include <sys/time.h>
#include <strings.h>
#include <string.h>
 
void exit_with_error(const char* msg) {
	if (msg == NULL)  
		perror("The following error occurred");
	else 
		perror(msg);
	exit(EXIT_FAILURE);
}
 
int main(int argc, char** argv) {
	int socket_id;							// socket descriptor
	struct sockaddr_in cli_sockaddr;		// socket address for client
	short server_port_num = 8001;			// port # for the server application
	const char* server_ip = "10.0.2.15";	// server IP address
 
	char reqstring[1000];					
	int i;
	int reqlen, total_bytes_sent, nbytes;
	int connect_code;
	
	/*
	 * 1. socket()  
	 */
	printf("creating a socket.\n");
	// TCP/IP 
	socket_id = socket(AF_INET, SOCK_STREAM, 0);
	// Socket 	
	if (socket_id == -1)  exit_with_error(NULL);			
 
		
	/*
	 * 2. connect to the server
	 */
	printf("connecting to the server.\n");
	
	cli_sockaddr.sin_family = AF_INET;		
	cli_sockaddr.sin_port = htons(server_port_num);
	cli_sockaddr.sin_addr.s_addr = inet_addr(server_ip);
	
	connect_code = connect(socket_id, (struct sockaddr *) &cli_sockaddr, sizeof(cli_sockaddr));
	if (connect_code == -1)	exit_with_error(NULL);		
	
		
	/*
	 * 3. send data
	 */
	printf("sending data to the server.\n");
	
	bzero(reqstring, sizeof(reqstring));	
	for (i=0; i<20; i++) reqstring[i] = 'X'; 
	strcpy(reqstring, "hello I'm Alice");
	reqlen = strlen(reqstring);
	
	total_bytes_sent = 0;
	while (total_bytes_sent < reqlen) {
		nbytes = write(socket_id, reqstring + total_bytes_sent, reqlen);	
		total_bytes_sent += nbytes;
	}
	printf("a total of %d bytes sent.\n", total_bytes_sent);
	
	return 0;	
}
