How to use “First Order Motion for Image Animation (2019)” Deepfake code:
1. Code is found here: https://colab.research.google.com/github/AliaksandrSiarohin/first-order-model/blob/master/demo.ipynb#scrollTo=Oxi6-riLOgnm
2. Runtime -> Run All
3. At the bottom, you’ll see that you can load your own images/videos, or use the preloaded media
3.a Creating the Image
3.a.i. Good headshot photo, non-complicated background. Size MUST be square - same width and height (dimensions are flexible, but something around 400x400 works).
4.a. Creating the Video
4.a.i. Video is ideally head tracked, but works fine without
4.a.ii. Video MUST be of dimensions 256x256
