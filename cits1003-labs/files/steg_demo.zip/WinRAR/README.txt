Requirements:
1. You must have WinRAR installed on your computer

Creating the stego

1. ensure you have an original image (e.g., original.jpg)
2. create a secret message text file(s)
3. create a .rar file containing all the secret messages (e.g., message.rar)
4. open cmd and navigate to the folder
5. run command
	copy /b original.jpg + message.rar hidden.jpg
   This creates a stego hidden.jpg file


Retrieving the secret message
1. open WinRAR and navitage to the folder containing hidden.jpg file
2. right click on the hidden.jpg file
3. press "show archive contents"
4. the secret message text file(s) should be visible inside