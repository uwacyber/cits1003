Requirements:
Need Python3

These code encode and decode secret message onto existing text files using white spaces.
an original text file has been provided to start with.
since we are encoding binary, we need a significantly large original file.

Encode
1) run encode.py - it will ask for the source text file, destination text file, 
   and secret message
2) if the secret message is too long, you will get an error message stating this
3) successfully encoding the secret message will display "encode successful!"

Decode
1) run decode.py - it will automatically decode the secret message
2) if decode is successful, it will display the secret message
3) if no secret message was present, it will display that message