import binascii

def text_to_bits(text, encoding='utf-8', errors='surrogatepass'):
    bits = bin(int(binascii.hexlify(text.encode(encoding, errors)), 16))[2:]
    return bits.zfill(8 * ((len(bits) + 7) // 8))

def int2bytes(i):
    hex_string = '%x' % i
    n = len(hex_string)
    return binascii.unhexlify(hex_string.zfill(n + (n & 1)))

def prep_original(ofile):
    lines = ofile.split('.')
    i = 0
    for i in range(len(lines)):
        lines[i] += '.\n' 
    return lines

def main():
    original = input("What is the original file name  : ")
    hidden = input("What would be the hidden file name: ")
    message = input("What is the secret message?      : ")
    ofile = open(original, 'r')
    hfile = open(hidden, 'w')
    #lines = prep_original(ofile.read())
    lines = ofile.readlines()
    h_bits = text_to_bits(message)
    print(h_bits)
    if len(h_bits) < len(lines):
        i = 0
        for line in lines:
            if i < len(h_bits):
                hfile.write(line[:-1] + ' ' * int(h_bits[i]) + '\n')
            else:
                hfile.write(line)
            i += 1

        print("encoding hidden message complete!")
    else:
        print("The message is too long to be hidden in the original file")
    ofile.close()
    hfile.close()
    return 0


if __name__ == "__main__":
    main()