Requirements:
1. Needs the Python Pillow (or PIL) library installed

The LSB steganography will embed bit information into the image file. If the image
format supports lossless compression (e.g., bmp), then the slight changes to the 
image won't be noticeable to the human eyes.

1. Run encoder.py to embed a secret message into an image using LSB steganography.
You must have an original message. an example space.png is provided.
Note: The output image must be a png format.

2. Run decoder.py to decode the secret message.