//
//  UploadDataToNoteViewController.swift
//  OpenTrace

import UIKit

class UploadDataToNoteViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
