//
//  Encounter+CoreDataClass.swift
//  OpenTrace

//

import Foundation
import CoreData

@objc(Encounter)
public class Encounter: NSManagedObject, Encodable {

}
