//
//  BluetraceConfig.swift
//  OpenTrace

import CoreBluetooth

import Foundation

struct BluetraceConfig {
    
    // To obtain the official BlueTrace Service ID and Characteristic ID, please email info@bluetrace.io
                                                                                                                     // b82ab3fc15954f6a80f0fe094cc218f9
    static let BluetoothServiceID = CBUUID(string: "\(PlistHelper.getvalueFromInfoPlist(withKey: "TRACER_SVC_ID") ?? "B82AB3FC-1595-4F6A-80F0-FE094CC218f9")")

    // Staging and Prod uses the same CharacteristicServiceIDv2, since BluetoothServiceID is different
    // static let CharacteristicServiceIDv2 = CBUUID(string: "\(PlistHelper.getvalueFromInfoPlist(withKey: "V2_CHARACTERISTIC_ID") ?? "D1034710-B11E-42F2-BCA3-F481177D5BB2")")
    //f918c24c09fef0806a4f9515fcb32ab8
    //static let CharacteristicServiceIDv2 = CBUUID(string: "\(PlistHelper.getvalueFromInfoPlist(withKey: "V2_CHARACTERISTIC_ID") ?? "D1034710-B11E-42F2-BCA3-F481177D5BB2")")
      
    
    //1 d0002d121e4b0fa4994eceb531f40579
    //2 7905f431b5ce4e99a40f4b1e122d00d0
    //  static let CharacteristicServiceIDv2 = CBUUID(string: "\(PlistHelper.getvalueFromInfoPlist(withKey: "V2_CHARACTERISTIC_ID") ?? "f918c24c-09fe-f080-6a4f-9515fcb32ab8")")
    static let CharacteristicServiceIDv2 = CBUUID(string: "\(PlistHelper.getvalueFromInfoPlist(withKey: "V2_CHARACTERISTIC_ID") ?? "B82AB3FC-1595-4F6A-80F0-FE094CC218f9")")

    static let charUUIDArray = [CharacteristicServiceIDv2]

    static let OrgID = "AU_DTA"
    static let ProtocolVersion = 1

    static let CentralScanInterval = 60 // in seconds
    static let CentralScanDuration = 10 // in seconds

    static let TTLDays = -21
}
