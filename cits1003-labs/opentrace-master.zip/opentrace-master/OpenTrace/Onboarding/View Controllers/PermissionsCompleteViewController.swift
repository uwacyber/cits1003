//
//  PermissionsCompleteViewController.swift
//  OpenTrace

import UIKit

class PermissionsCompleteViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
