//
//  IntroViewController.swift
//  OpenTrace

import UIKit
// import FirebaseAuth

class IntroViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
}
